// src/App.jsx
import React, { useState, useEffect } from 'react';
import { RegisterView } from './components/RegisterView';
import { ProductsView } from './components/ProductsView';
import { ClientsView } from './components/ClientsView';
import { SuppliersView } from './components/SuppliersView';
import { SettingsView } from './components/SettingsView';
import { WarehousesView } from './components/WarehousesView';
import { TopMenuBar } from './components/TopMenuBar';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';

const API_URL = 'http://localhost:3000';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || null);
  const [isRegistering, setIsRegistering] = useState(false);

  // Estado para la navegación interna (dashboard, products, suppliers, clients, warehouses, settings)
  const [currentView, setCurrentView] = useState('dashboard');

  // Estados de autenticación y registro
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [taxId, setTaxId] = useState('');
  const [region, setRegion] = useState('Latam');
  const [country, setCountry] = useState('República Dominicana');
  const [userFunction, setUserFunction] = useState('Comerciante / Retail');
  const [planType, setPlanType] = useState('trial');
  const [planCategory, setPlanCategory] = useState('');
  const [planSubcategory, setPlanSubcategory] = useState('');
  const [deviceUuid, setDeviceUuid] = useState('device-uuid-test-01');

  const handleLogout = () => {
    setToken('');
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setCurrentView('dashboard');
  };

  // Control de inactividad para Navegador Web
  useEffect(() => {
    if (!token) return;

    const timeoutMinutes = user?.sessionTimeoutMinutes || 15;
    let timeoutId;

    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        alert('Su sesión ha expirado por inactividad.');
        handleLogout();
      }, timeoutMinutes * 60 * 1000);
    };

    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keypress', resetTimer);
    window.addEventListener('click', resetTimer);

    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keypress', resetTimer);
      window.removeEventListener('click', resetTimer);
    };
  }, [token, user]);

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (res.ok) {
        setToken(data.accessToken);
        setUser(data.user);
        localStorage.setItem('token', data.accessToken);
        localStorage.setItem('user', JSON.stringify(data.user));
        alert('¡Login exitoso!');
      } else {
        alert(data.message || 'Error en el login');
      }
    } catch (err) {
      console.error(err);
      alert('Error de conexión con el servidor');
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          companyName,
          email,
          phone,
          taxId: taxId || undefined,
          region,
          country,
          userFunction,
          planType,
          planCategory,
          planSubcategory,
          deviceUuid,
          password: password || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        alert('¡Registro exitoso! Ahora puedes iniciar sesión.');
        setIsRegistering(false);
        setPassword('');
      } else {
        alert(data.message || 'Error en el registro');
      }
    } catch (err) {
      console.error(err);
      alert('Error de conexión con el servidor');
    }
  };

  if (!token) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
        <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-sm border border-slate-200">
          <h2 className="mb-6 text-center text-2xl font-bold text-slate-800">
            {isRegistering ? 'TMS Profesional - Registro (Admin)' : 'TMS Profesional - Login'}
          </h2>

          {isRegistering ? (
            <RegisterView
              name={name}
              setName={setName}
              companyName={companyName}
              setCompanyName={setCompanyName}
              phone={phone}
              setPhone={setPhone}
              taxId={taxId}
              setTaxId={setTaxId}
              region={region}
              setRegion={setRegion}
              country={country}
              setCountry={setCountry}
              userFunction={userFunction}
              setUserFunction={setUserFunction}
              planType={planType}
              setPlanType={setPlanType}
              planCategory={planCategory}
              setPlanCategory={setPlanCategory}
              planSubcategory={planSubcategory}
              setPlanSubcategory={setPlanSubcategory}
              email={email}
              setEmail={setEmail}
              password={password}
              setPassword={setPassword}
              handleRegister={handleRegister}
              setIsRegistering={setIsRegistering}
            />
          ) : (
            <form onSubmit={handleLogin}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-600">Correo Electrónico</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 bg-slate-50 p-2.5 text-slate-800 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-500/15 focus:outline-none transition-colors"
                  required
                />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-600">Contraseña</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-slate-300 bg-slate-50 p-2.5 text-slate-800 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-500/15 focus:outline-none transition-colors"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full rounded-lg bg-blue-600 p-2.5 font-semibold text-white shadow-sm shadow-blue-600/20 hover:bg-blue-700 transition-colors"
              >
                Iniciar Sesión
              </button>
              <p className="mt-4 text-center text-sm">
                <button
                  type="button"
                  onClick={() => setIsRegistering(true)}
                  className="text-blue-600 hover:text-blue-700 hover:underline"
                >
                  ¿No tienes cuenta? Regístrate aquí
                </button>
              </p>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-slate-50 text-slate-800 flex flex-col overflow-hidden">
      {/* BARRA SUPERIOR DE MENÚS */}
      <TopMenuBar currentView={currentView} onNavigate={setCurrentView} />

      {/* BARRA DE USUARIO / SESIÓN */}
      <div className="flex items-center justify-between bg-white border-b border-slate-200 px-6 py-3 shrink-0">
        <div>
          <h1 className="text-xl font-bold text-blue-600">TMS Profesional</h1>
          <p className="text-xs text-slate-500">
            Rol: <span className="text-slate-700 uppercase font-semibold">{user?.role}</span>
            {user?.subRole && ` (${user.subRole})`}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600">
            Usuario: <strong className="text-slate-800">{user?.name || user?.email}</strong>
          </span>
          <button
            onClick={handleLogout}
            className="rounded-lg bg-red-50 border border-red-200 px-4 py-2 text-sm font-semibold text-red-600 hover:bg-red-100 transition-colors"
          >
            Cerrar Sesión
          </button>
        </div>
      </div>

      {/* CONTENEDOR PRINCIPAL: SIDEBAR + CONTENIDO */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar currentView={currentView} onNavigate={setCurrentView} />

        <main className="flex-1 overflow-y-auto p-6 bg-slate-50">
          <div className="mx-auto max-w-6xl">
            {currentView === 'products' ? (
              <ProductsView token={token} />
            ) : currentView === 'suppliers' ? (
              <SuppliersView token={token} />
            ) : currentView === 'warehouses' ? (
              <WarehousesView token={token} />
            ) : currentView === 'settings' ? (
              <SettingsView token={token} user={user} setUser={setUser} />
            ) : currentView === 'clients' ? (
              <ClientsView token={token} />
            ) : (
              <Dashboard user={user} token={token} onNavigate={setCurrentView} />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
